<script>
   var input = document.getElementById('clear');
   input.value = "" ;
</script>

<?php

require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );

global $wpdb;
$path = $_SERVER['DOCUMENT_ROOT'];

// SELECT 
// $select_meubles_admin = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles " );

$select_bureau_admin  = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'bureau' " );
$select_chambre_admin = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'chambre' " );
$select_cuisine_admin = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'cuisine' " );
$select_enfant_admin  = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'enfant' " );
$select_entree_admin  = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'entree' " );
$select_sdb_admin     = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'sdb' " );
$select_salon_admin   = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'salon' " );

$table_name_meubles = "wp_edit_image_meubles";
$table_name_paints = "wp_edit_image_paints"; 

$charset_collate = $wpdb->get_charset_collate();

$sql_meubles = "CREATE TABLE $table_name_meubles (
		  id mediumint(9) NOT NULL AUTO_INCREMENT,
		  name tinytext NULL,
          name_meuble varchar(255) DEFAULT NULL,
		  url_couleur varchar(255) DEFAULT NULL,
          url_noir_blanc varchar(255) DEFAULT NULL,
          category varchar(255) DEFAULT NULL,
		  created timestamp NOT NULL default CURRENT_TIMESTAMP,
		  UNIQUE KEY id (id)
		) $charset_collate;";

$sql_paints = "CREATE TABLE $table_name_paints (
         id mediumint(9) NOT NULL AUTO_INCREMENT,
         name tinytext NULL,
         name_paint varchar(255) DEFAULT NULL,
         url_couleur varchar(255) DEFAULT NULL,
         url_noir_blanc varchar(255) DEFAULT NULL,
         category varchar(255) DEFAULT '' NOT NULL,
         created timestamp NOT NULL default CURRENT_TIMESTAMP,
         UNIQUE KEY id (id)
        ) $charset_collate;";

dbDelta( $sql_meubles );
dbDelta( $sql_paints );

    // Paint Uploads
    if (isset($_POST['upload_paint'])) {

        // nom
        $name_paint = $_POST['name_paint'] ;

        // category
        $category = $_POST['category'] ;
    
        // image en couleur
        $url_couleur = $_FILES["url_couleur"]["name"];
        $url_couleur_temp_name = $_FILES["url_couleur"]["tmp_name"];
        $folder_couleur = $_SERVER["DOCUMENT_ROOT"] . "/wp-content/plugins/edit-image/Publics/Images/paints/" . $url_couleur; // ****************
        $url_couleur_final = "/wp-content/plugins/edit-image/Publics/Images/paints/" .  $url_couleur;

        // image noir et blanc
        $url_noir_blanc = $_FILES["url_noir_blanc"]["name"];
        $url_noir_blanc_temp_name = $_FILES["url_noir_blanc"]["tmp_name"];
        $folder_url_noir_blanc = $_SERVER["DOCUMENT_ROOT"] . "/wp-content/plugins/edit-image/Publics/Images/paints/" . $url_noir_blanc; // ****************
        $url_noir_blanc_final = "/wp-content/plugins/edit-image/Publics/Images/paints/" .  $url_noir_blanc;


        $search  = array('.jpeg', '.jpg', '.png');
        $name = str_replace( $search, '', $url_noir_blanc );
        $name_no_space = strtolower( str_replace( ' ', '_', $name ) ) ;
            
        $sqlInsertPaint = "INSERT INTO wp_edit_image_paints (name, name_paint , url_couleur, url_noir_blanc, category) VALUES ('$name_no_space', '$name_paint', '$url_couleur_final', '$url_noir_blanc_final', '$category')";
    
        move_uploaded_file($url_couleur_temp_name, $folder_couleur) ;
        move_uploaded_file($url_noir_blanc_temp_name, $folder_url_noir_blanc) ;

       include $path . "/wp-content/plugins/edit-image/Controller/refresh.php"; //**************** */
    
        dbDelta( $sqlInsertPaint );

    
    }


    // Meubles Uploads
    if (isset($_POST['upload_meuble'])) {

        // nom
        $name_meuble = $_POST['name_meuble'] ;

        // category
        $category = $_POST['category'] ;
    
        // image en couleur
        $url_couleur = $_FILES["url_couleur"]["name"];
        $url_couleur_temp_name = $_FILES["url_couleur"]["tmp_name"];
        $folder_couleur = $_SERVER["DOCUMENT_ROOT"] . "/wp-content/plugins/edit-image/Publics/Images/meubles/" . $url_couleur; // ****************
        $url_couleur_final = "/wp-content/plugins/edit-image/Publics/Images/meubles/" .  $url_couleur;

        // image noir et blanc
        $url_noir_blanc = $_FILES["url_noir_blanc"]["name"];
        $url_noir_blanc_temp_name = $_FILES["url_noir_blanc"]["tmp_name"];
        $folder_url_noir_blanc = $_SERVER["DOCUMENT_ROOT"] . "/wp-content/plugins/edit-image/Publics/Images/meubles/" . $url_noir_blanc; // ****************
        $url_noir_blanc_final = "/wp-content/plugins/edit-image/Publics/Images/meubles/" .  $url_noir_blanc;


        $search  = array('.jpeg', '.jpg', '.png');
        $name = str_replace( $search, '', $url_noir_blanc );
        $name_no_space = strtolower( str_replace( ' ', '_', $name ) ) ;
            
        $sqlInsertMeuble = "INSERT INTO wp_edit_image_meubles (name, name_meuble , url_couleur, url_noir_blanc, category) VALUES ('$name_no_space', '$name_meuble', '$url_couleur_final', '$url_noir_blanc_final', '$category')";
    
        move_uploaded_file($url_couleur_temp_name, $folder_couleur) ;
        move_uploaded_file($url_noir_blanc_temp_name, $folder_url_noir_blanc ) ;

       include $path . "/wp-content/plugins/edit-image/Controller/refresh.php"; //**************** */


       dbDelta( $sqlInsertMeuble );

   
    }

?>

    <div class="container x-marge">
        <h2 class="float-left" >Mise en situation</h2>

        <!-- Button trigger modal -->
        <button type="button" class="btn float-right" data-toggle="modal" data-target="#exampleModal">Televerser une image</button>
    </div>


    <div class="container marge">

        <div class="row" >

            <!-- ******************************************* first ********************************************** -->
            <div class="col-md-6" >

                <div class="container body-admin">

                    <div class="row colapse-div" data-toggle="collapse" data-target="#demo1" >
                        <div class="col-md-8" >
                            <h6 >Bureau</h6>
                        </div>
                        <div class="col-md-2" >
                            <h6 ></h6>
                        </div>
                        <div class="col-md-2" >
                            <h6></h6>
                        </div>
                    </div>

                    <div id="demo1" class="collapse">
                        <?php
                            foreach ($select_bureau_admin as $k ) {
 
                              echo '
                                    <div class="row" >
                                        <div class="col-md-3" >
                                            <p> ' . $k->name_meuble . '</p>
                                        </div>

                                        <div class="col-md-3" > ' ;

                                        if ( $k->url_couleur != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                            echo '<img width="105" height="70" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" > ' ;
                                        }
                                           
                                echo '</div>

                                        <div class="col-md-3" > ' ;

                                        if ( $k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                            echo '<img width="105" height="70" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                        }
                                            
                                echo '</div>

                                        <div class="col-md-2" >

                                        </div>

                                        <div class="col-md-1" >
                                            <p><a style="color: red !important;" href="/wp-content/plugins/edit-image/Controller/delete_meuble.php?delete='. $k->id .'&category='. $k->category .'" >X</a></p>
                                        </div>
                                    </div>

                                    ' ;

                            }
                        ?>
                    </div>

                </div>

                <div class="container body-admin">

                    <div class="row colapse-div" data-toggle="collapse" data-target="#demo2" >
                        <div class="col-md-8" >
                            <h6 >Chambre</h6>
                        </div>
                        <div class="col-md-2" >
                            <h6 ></h6>
                        </div>
                        <div class="col-md-2" >
                            <h6></h6>
                        </div>
                    </div>

                    <div id="demo2" class="collapse">
                        <?php
                            foreach ($select_chambre_admin as $k ) {
 
                              echo '
                                    <div class="row" >
                                        <div class="col-md-3" >
                                            <p> ' . $k->name_meuble . '</p>
                                        </div>

                                        <div class="col-md-3" > ' ;

                                        if ( $k->url_couleur != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                            echo '<img width="105" height="70" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" > ' ;
                                        }
                                           
                                echo '</div>

                                        <div class="col-md-3" > ' ;

                                        if ( $k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                            echo '<img width="105" height="70" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                        }
                                            
                                echo '</div>

                                        <div class="col-md-2" >

                                        </div>

                                        <div class="col-md-1" >
                                            <p><a style="color: red !important;" href="/wp-content/plugins/edit-image/Controller/delete_meuble.php?delete='. $k->id .'&category='. $k->category .'" >X</a></p>
                                        </div>
                                    </div>

                                    ' ;

                            }
                        ?>
                    </div>

                </div>

                <div class="container body-admin">

                    <div class="row colapse-div" data-toggle="collapse" data-target="#demo3" >
                        <div class="col-md-8" >
                            <h6 >Cuisine</h6>
                        </div>
                        <div class="col-md-2" >
                            <h6 ></h6>
                        </div>
                        <div class="col-md-2" >
                            <h6></h6>
                        </div>
                    </div>

                    <div id="demo3" class="collapse">
                        <?php
                            foreach ($select_cuisine_admin as $k ) {
 
                            echo '
                                <div class="row" >
                                    <div class="col-md-3" >
                                        <p> ' . $k->name_meuble . '</p>
                                    </div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_couleur != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" > ' ;
                                    }
                                       
                            echo '</div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                    }
                                        
                            echo '</div>

                                    <div class="col-md-2" >

                                    </div>

                                    <div class="col-md-1" >
                                        <p><a style="color: red !important;" href="/wp-content/plugins/edit-image/Controller/delete_meuble.php?delete='. $k->id .'&category='. $k->category .'" >X</a></p>
                                    </div>
                                </div>

                                ' ;
                            }
                        ?>
                    </div>

                </div>

                <div class="container body-admin">

                    <div class="row colapse-div" data-toggle="collapse" data-target="#demo4" >
                        <div class="col-md-8" >
                            <h6 >Enfant</h6>
                        </div>
                        <div class="col-md-2" >
                            <h6 ></h6>
                        </div>
                        <div class="col-md-2" >
                            <h6></h6>
                        </div>
                    </div>

                    <div id="demo4" class="collapse">
                        <?php
                            foreach ($select_enfant_admin as $k ) {
 
                            echo '
                                <div class="row" >
                                    <div class="col-md-3" >
                                        <p> ' . $k->name_meuble . '</p>
                                    </div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_couleur != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" > ' ;
                                    }
                                       
                            echo '</div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                    }
                                        
                            echo '</div>

                                    <div class="col-md-2" >

                                    </div>

                                    <div class="col-md-1" >
                                        <p><a style="color: red !important;" href="/wp-content/plugins/edit-image/Controller/delete_meuble.php?delete='. $k->id .'&category='. $k->category .'" >X</a></p>
                                    </div>
                                </div>

                                ' ;
                            }
                        ?>
                    </div>

                </div>

            </div>


            <!-- ******************************************* second ********************************************** -->
            <div class="col-md-6" >

                <div class="container body-admin">

                    <div class="row colapse-div" data-toggle="collapse" data-target="#demo5" >
                        <div class="col-md-8" >
                            <h6 >Entrée</h6>
                        </div>
                        <div class="col-md-2" >
                            <h6 ></h6>
                        </div>
                        <div class="col-md-2" >
                            <h6></h6>
                        </div>
                    </div>

                    <div id="demo5" class="collapse">
                        <?php
                            foreach ($select_entree_admin as $k ) {
 
                                echo '
                                <div class="row" >
                                    <div class="col-md-3" >
                                        <p> ' . $k->name_meuble . '</p>
                                    </div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_couleur != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" > ' ;
                                    }
                                       
                            echo '</div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                    }
                                        
                            echo '</div>

                                    <div class="col-md-2" >

                                    </div>

                                    <div class="col-md-1" >
                                        <p><a style="color: red !important;" href="/wp-content/plugins/edit-image/Controller/delete_meuble.php?delete='. $k->id .'&category='. $k->category .'" >X</a></p>
                                    </div>
                                </div>

                                ' ;
                            }
                        ?>
                    </div>

                </div>

                <div class="container body-admin">

                    <div class="row colapse-div" data-toggle="collapse" data-target="#demo6" >
                        <div class="col-md-8" >
                            <h6 >Salle de bain</h6>
                        </div>
                        <div class="col-md-2" >
                            <h6 ></h6>
                        </div>
                        <div class="col-md-2" >
                            <h6></h6>
                        </div>
                    </div>

                    <div id="demo6" class="collapse">
                        <?php
                            foreach ($select_sdb_admin as $k ) {
 
                            echo '
                                <div class="row" >
                                    <div class="col-md-3" >
                                        <p> ' . $k->name_meuble . '</p>
                                    </div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_couleur != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" > ' ;
                                    }
                                       
                            echo '</div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                    }
                                        
                            echo '</div>

                                    <div class="col-md-2" >

                                    </div>

                                    <div class="col-md-1" >
                                        <p><a style="color: red !important;" href="/wp-content/plugins/edit-image/Controller/delete_meuble.php?delete='. $k->id .'&category='. $k->category .'" >X</a></p>
                                    </div>
                                </div>

                                ' ;
                            }
                        ?>
                    </div>

                </div>

                <div class="container body-admin">

                    <div class="row colapse-div" data-toggle="collapse" data-target="#demo7" >
                        <div class="col-md-8" >
                            <h6 >Salon</h6>
                        </div>
                        <div class="col-md-2" >
                            <h6 ></h6>
                        </div>
                        <div class="col-md-2" >
                            <h6></h6>
                        </div>
                    </div>

                    <div id="demo7" class="collapse">
                        <?php
                            foreach ($select_salon_admin as $k ) {
 
                            echo '
                                <div class="row" >
                                    <div class="col-md-3" >
                                        <p> ' . $k->name_meuble . '</p>
                                    </div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_couleur != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" > ' ;
                                    }
                                       
                            echo '</div>

                                    <div class="col-md-3" > ' ;

                                    if ( $k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                        echo '<img width="105" height="70" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                    }
                                        
                            echo '</div>

                                    <div class="col-md-2" >

                                    </div>

                                    <div class="col-md-1" >
                                        <p><a style="color: red !important;" href="/wp-content/plugins/edit-image/Controller/delete_meuble.php?delete='. $k->id .'&category='. $k->category .'" >X</a></p>
                                    </div>
                                </div>

                                ' ;
                            }
                        ?>
                    </div>

                </div>

            </div>
        </div>

    </div>



<!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Televerser votre image</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>

      <div class="modal-body">

            <div class="choice" >
                <!-- <button type="button" class="btn btn-primary float-left" id="btn-paint" >Televerser une Paint</button> -->
                <button type="button" class="btn btn-primary float-right" id="btn-meuble">Televerser un Meuble</button>
            </div>

            <div class="marge" >


                <!-- *************** meuble ********** -->
                <div class="meuble-form" >
                
                    <form method="POST" action="" enctype="multipart/form-data" >

                        <!-- *************** Category ********** -->
                        <div class="category" >
                            <div class="form-group">
                                <label for="exampleFormControlSelect1">Veuillez Selectioner une categorie</label>
                                <select class="form-control" name="category">
                                    <option value="bureau" >Bureau</option>
                                    <option value="chambre" >Chambre</option>
                                    <option value="cuisine" >Cuisine</option>
                                    <option value="enfant" >Enfant</option>
                                    <option value="entree" >Entrée</option>
                                    <option value="sdb" >Salle de bain</option>
                                    <option value="salon" >Salon</option>
                                </select>
                            </div>
                        </div>

                        <div class="form-group">
                            <label for=""> Nom de la mise en situation Meuble </label>
                            <input type="text" class="form-control" id="meuble_nom" name="name_meuble" placeholder="Nom de la mise en situation">
                        </div>

                        <div class="form-group">
                            <label for=""> Image Fond Transparent </label>
                            <input type="file" class="form-control" id="meuble_url_couleur" name="url_couleur" placeholder="Image en couleur">
                        </div>

                        <div class="form-group">
                            <label for=""> Image Fond Gris </label>
                            <input type="file" class="form-control" id="meuble_url_noir_blanc" name="url_noir_blanc" placeholder="Image noir et blanc">
                        </div>

                        <button type="submit" class="btn btn-primary" name="upload_meuble" >Enregistrer</button>

                    </form>

                </div>

                <!-- *************** paint ********** -->
                <!-- <div class="paint-form" >

                    <form method="POST" action="" enctype="multipart/form-data" >

                        <div class="form-group">
                            <label for=""> Nom de la mise en situation Paint </label>
                            <input type="text" class="form-control" id="paint_nom" name="name_paint" placeholder="Nom de la mise en situation">
                        </div>

                        <div class="form-group">
                            <label for=""> Image en couleur du Paint </label>
                            <input type="file" class="form-control" id="paint_url_couleur" name="url_couleur" placeholder="Image en couleur">
                        </div>

                        <div class="form-group">
                            <label for=""> Image noir et blanc du Paint </label>
                            <input type="file" class="form-control" id="paint_url_noir_blanc" name="url_noir_blanc" placeholder="Image noir et blanc">
                        </div>

                        <button type="submit" class="btn btn-primary" name="upload_paint" >Enregistrer</button>

                    </form>

                </div> -->

            </div>


      </div>

    </div>
  </div>
</div>