<?php
    
    $path = $_SERVER['DOCUMENT_ROOT'];

    include_once $path . '/wp-config.php'; //*************** */
    include_once $path . '/wp-load.php';//*************** */
    include_once $path . '/wp-includes/wp-db.php';//*************** */
    include_once $path . '/wp-includes/pluggable.php';//*************** */

    $id = $_GET['delete'];
    $cat = $_GET['category'] ;

    $wpdb->query($wpdb->prepare("DELETE FROM wp_edit_image_paints WHERE id ='$id' AND category = '$cat' "));

    header('Location: ' . $_SERVER['HTTP_REFERER']);
    
    exit;
        
        

?>