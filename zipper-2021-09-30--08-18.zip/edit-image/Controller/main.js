$(document).ready(function() {

    var bg_img_link = $('.woocommerce-product-gallery__image').last()[0].firstChild.children[0].currentSrc ;
    $('.entry-summary').append('<button id="modifier" >Personnaliser pour avoir une visuelle</button>') ;
    // var img_final = '<img id="img-final" src="' + img_link + '" alt="">' ;

    var bg_img_paint = 'background-image: url("'+ bg_img_link +'")' ; 

    $('#modifier').on('click', function() {

        $.get( "/wp-content/plugins/edit-image/Views/index.php", function( data ) { //**************** */

            $( ".single .woocommerce-tabs" ).html( data );
    
        //    $(img_final).appendTo("#showData"); 
           $('#showData').attr('style', bg_img_paint );
    
            var timesClickedMeubles = 0;
            var timesClickedPaint = 0;
    
            $(".img-meubles").click(function() {
                
              timesClickedMeubles++;
    
                if (timesClickedMeubles%2 == 0) {
                    $('#showData .img-meubles').remove() ;
                } else {
                    $('#showData .img-meubles').remove() ;
                    $(this).clone().appendTo("#showData");
                }
            })
    
            $(".img-paint").click(function() {
              timesClickedPaint++;
    
              if (timesClickedPaint%2 == 0) {
                   $('#showData .img-paint').remove() ;
                   $('#showData').css({'background-image': 'url("'+ bg_img_link +'")'}) ;
              } else {
                  $('#showData .img-paint').remove() ;
                  $(this).clone().appendTo("#showData"); 
                  $("#showData .img-paint").addClass('zindex');
                //   var url_meuble_fond = $(".pixel_bg")[0].currentSrc ;
                  var url_meuble_fond = $(this).next().filter('.pixel_bg')[0].currentSrc ;
                //   console.log(url_meuble_fond) ;
                //   var bg_img_final = 'background-image: url("'+ bg_img_link +'"), url("'+url_meuble_fond+'")' ; 
                  $('#showData').css({'background-image': 'url("'+ url_meuble_fond +'"), url("'+ bg_img_link +'")'}) ;
                  $('#showData').css({'background-blend-mode': 'multiply'}) ;
              }
            })
    
        });

    })
        
} )