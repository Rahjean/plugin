$(document).ready(function(){
    
        function movebg(params){
            var $bg = $('div#showDataShortcode'),
            origin = {x: 0, y: 0},
            start = {x: 0, y: 0},
            movecontinue = false;

        function move (e){
            var moveby = {
                x: origin.x - e.clientX,
                y: origin.y - e.clientY
            };

                if (movecontinue === true) {
                    start.x = start.x - moveby.x;
                    start.y = start.y - moveby.y;  
                    
                    if(params){
                        var get =  localStorage.getItem("drag_img");
                        $(this).css(get,'0px 0px,'+start.x + 'px ' + start.y + 'px');
                    }

                origin.x = e.clientX;
                origin.y = e.clientY;
    
                e.stopPropagation();
                return false;
                         
                }
        }

        function handle (e){
            movecontinue = false;
            $bg.unbind('mousemove', move);

            if (e.type == 'mousedown') {
                origin.x = e.clientX;
                origin.y = e.clientY;
                movecontinue = true;
                $bg.bind('mousemove', move);
            } else {
                $(document.body).focus();
            }

            e.stopPropagation();
            return false;
        }

        function reset (){
            start = {x: 0, y: 0};
            $(this).css('backgroundPosition', '0 0');
        }

        $bg.bind('mousedown mouseup mouseleave', handle);
        $bg.bind('dblclick', reset);
    }

    function custom(){

        $("button#drag").click(function() {

            var text = $(this).find('b').text();

            if(text == 'Déplacer'){
            $(this).find('b').text('Fixer');
            
                localStorage.setItem("drag_img","background-position");
                setTimeout(() => {
                        movebg(true);
                    }, 500);
            }
            else{
            $(this).find('b').text('Déplacer');
            
                localStorage.removeItem("drag_img");
                setTimeout(() => {
                movebg(false);
                }, 500);
            }
    
        });



        jQuery(document).on('click','button#builder-init',function(){
            var largeur = jQuery('input#largeur').val();
            var hauteur = jQuery('input#hauteur').val();
            
            if(largeur != null && hauteur != null){
                jQuery('div#showDataShortcode').css({'background-size':'100% 100% , '+largeur+'cm '+hauteur+'cm'});
            }
        });
    }


    localStorage.removeItem("isFunctionRunning");

    
    $.get( "/wp-content/plugins/edit-image/Views/short_code.php", function( data ) {


        $( "#custom_edit_shortcode" ).html( data );

        $( ".section_boutton" ).each(function( index ) {
            
            if( $(this).text().trim() != "Carte" && $(this).text().trim() != "Contemporain" && $(this).text().trim() != "Enfant / Ados" && $(this).text().trim() != "Nature" && $(this).text().trim() != "Collections" && $(this).text().trim() != "Canvas" && $(this).text().trim() != "Fluide Art" && $(this).text().trim() != "Géométrie" && $(this).text().trim() != "Texture" ) {

                $(this).parent().parent().css("display", "none");
            }
    
        });


        if ( $('#showDataShortcode').children().length > 0 ) {
            $('#btnCrop').hide();
        }
        else {
            $('#btnCrop').show();
        }

        var timesClickedMeubles = 0;

        $('.myModel').hide();
        $('#btnCrop').hide();

        $(".img-paint-shortcode").click(function() {

            $('#canvas_empty').empty();

            setTimeout(() => {

                $('#canvas_empty').append('<canvas id="canvas"> Your browser does not support the HTML5 canvas element.  </canvas>') ;
                $('#showDataShortcode').css({'background-position': 'inherit' }) ;
                                
            }, 1000);



            $('.myModel').show();
            
                timesClickedMeubles++;

                var second_link_all = $('#showDataShortcode')[0].style.backgroundImage;
                var second_link_final_meuble = second_link_all.split(',')[0] ;
                
                if (timesClickedMeubles%2 == 0) {
                    
                    if(second_link_final_meuble == false) {
                      var url_meuble_fond = $(this)[0].currentSrc ;
                      $('#showDataShortcode').css({'background-image': 'url("'+ url_meuble_fond +'")'}) ;
                      $('#showDataShortcode').css({'background-size': 'cover' }) ;

                    }

                    if(second_link_final_meuble) {
                        
                        if ( $('#showDataShortcode').children().length > 0 ) {
                           
                            var url_paint = $(this)[0].currentSrc ;
                            $('#showDataShortcode').css({'background-image': second_link_final_meuble + ',' + 'url("'+ url_paint +'")' }) ;
                            $('#showDataShortcode').css({'background-size': '100% 100%, cover' }) ;

                        }
                        else {
                            var url_meuble_fond = $(this)[0].currentSrc ;
                            $('#showDataShortcode').css({'background-image': 'url("'+ url_meuble_fond +'")'}) ;
                            $('#showDataShortcode').css({'background-size': 'cover' }) ;

                        }
                    }
                    else {
                        var url_meuble_fond = $(this)[0].currentSrc ;
                        $('#showDataShortcode').css({'background-image': 'url("'+ url_meuble_fond +'")'}) ;
                        $('#showDataShortcode').css({'background-size': 'cover' }) ;

                    }

                } else {

                    if(second_link_final_meuble) {

                        var url_paint = $(this)[0].currentSrc ;

                        if ( $('#showDataShortcode').children().length > 0 ) {
                            
                            if(url_paint) {
 
                                if ( $('#showDataShortcode').children().length > 0 ) {
                                    $('#showDataShortcode').css({'background-size': '100% 100%, cover' }) ;
                                    setTimeout(() => {
                                        $(this).click() ;
                                    }, 50);
                                }
                                else {
                                    $('#showDataShortcode').css({'background-image': second_link_final_meuble + ',' + 'url("'+ url_paint +'")' }) ;
                                    $('#showDataShortcode').css({'background-size': 'cover' }) ;
                                }

                             }
    
                             else {

                                $('#showDataShortcode').css({'background-image': second_link_final_meuble + ',' + 'url("'+ url_paint +'")' }) ;
                                $('#showDataShortcode').css({'background-size': 'cover' }) ;
                             }
                            

                        }
                        else {

                            setTimeout(() => {
                                $(this).click() ;
                            }, 100);
                       }

                    }
                    else {
  
                        var url_meuble_fond = $(this)[0].currentSrc ;
                        $('#showDataShortcode').css({'background-image': 'url("'+ url_meuble_fond +'")'});
                        $('#showDataShortcode').css({'background-size': 'cover' }) ;

                    }
                }
              
        });

        $(".z-index").click(function(){

            if ( $('#showDataShortcode').children().length > 0 ) {
                $('#btnCrop').show();
                $('#showDataShortcode .z-index').remove() ;
                var url_meuble_fond = $(this).next().filter('.pixel_bg_shortcode')[0].currentSrc ;
                var bg_img_paint_second = $("#showDataShortcode").css("background-image")
                bg_img_paint_second = bg_img_paint_second.replace(/.*\s?url\([\'\"]?/, '').replace(/[\'\"]?\).*/, '')
                $('#showDataShortcode').css({'background-image': 'url("'+ url_meuble_fond +'"), url("'+ bg_img_paint_second +'")'}) ;
                $('#showDataShortcode').css({'background-blend-mode': 'multiply'}) ;
                $(this).clone().appendTo("#showDataShortcode");
    
                var checkFunction = localStorage.getItem("isFunctionRunning");

                if(checkFunction != 1){
                    custom();
                    localStorage.setItem("isFunctionRunning",1); 
                }

            }
            else {
                $('#btnCrop').show();
                $('#showDataShortcode .z-index').remove() ;
                var url_meuble_fond = $(this).next().filter('.pixel_bg_shortcode')[0].currentSrc ;
                var bg_img_paint_second = $("#showDataShortcode").css("background-image")
                bg_img_paint_second = bg_img_paint_second.replace(/.*\s?url\([\'\"]?/, '').replace(/[\'\"]?\).*/, '')
                $('#showDataShortcode').css({'background-image': 'url("'+ url_meuble_fond +'"), url("'+ bg_img_paint_second +'")'}) ;
                $('#showDataShortcode').css({'background-blend-mode': 'multiply'}) ;
                $('#showDataShortcode').css({'background-size': '100% 100% , cover'});
                $(this).clone().appendTo("#showDataShortcode");
    
                var checkFunction = localStorage.getItem("isFunctionRunning");
                if(checkFunction != 1){
                    custom();
                    localStorage.setItem("isFunctionRunning",1); 
                }
            }


        });




        // CROPPER IMAGE
        $("#btnCrop").on('click', function(){

                var second_link_all = $('#showDataShortcode')[0].style.backgroundImage;
                second_link_final_meuble = second_link_all.split(',')[1] ;
                var url_final = second_link_final_meuble.replace(/.*\s?url\([\'\"]?/, '').replace(/[\'\"]?\).*/, '') ;

                var img = new Image();
                img.onload = function() {
                  console.log( this.width + 'zz' + this.height ) ;
                  if (this.width > 1000) {
                    $('.modal-content').css({'width': '1000' }); 
                  }
                  else {
                    $('.modal-content').css({'width': this.width }); 
                    //$('.cropper-container .cropper-bg').css({'height': this.height }); 
                  }

                }
                img.src = url_final ;


                

                var first_link_all = $('#showDataShortcode')[0].style.backgroundImage;
                var first_link_all_final = first_link_all.split(',')[0] ;
    
                var second_link_all = $('#showDataShortcode')[0].style.backgroundImage;
                var url_regex = second_link_all.split(',')[1] ;
    
                var url_no_characteur = url_regex.replace(/[("]/g,'');
    
                var url = url_no_characteur.replace('url', '') ;
                
                var canvas  = $("#canvas"),
                context = canvas.get(0).getContext("2d"), 
                $result = $('#builder_popup');
    
                var request = new XMLHttpRequest();
                request.open('GET', url, true);
                request.responseType = 'blob';
                request.onload = function() {
                    var reader = new FileReader();
                    reader.readAsDataURL(request.response);
                    reader.onload =  function(e){
    
                        var base64 = e.target.result ;
    
                        function dataURLtoFile(dataurl, filename) {
     
                            var arr = dataurl.split(','),
                                mime = arr[0].match(/:(.*?);/)[1],
                                bstr = atob(arr[1]), 
                                n = bstr.length, 
                                u8arr = new Uint8Array(n);
                                
                            while(n--){
                                u8arr[n] = bstr.charCodeAt(n);
                            }
                            
                            return new File([u8arr], filename, {type:mime});
                        }
                        
                        //Usage example:
                        var file = dataURLtoFile(base64 ,'cropper.jpeg');
                       
                        if ( file.type.match(/^image\//) ) {
     
                            var reader = new FileReader();
    
                            reader.onload = function(evt) {
                               var img = new Image();
                               img.onload = function() {
                                 context.canvas.height = img.height;
                                 context.canvas.width  = img.width;
                                 context.drawImage(img, 0, 0);
                                 var cropper = canvas.cropper({
                                //    aspectRatio: 16 / 4
                                        zoomable: false,
                                        dragMode: false,
                                        // left: 0,
                                 });

                       $('#saveCropper').click(function() {
                           
                                setTimeout(()=>{

                                 // Get a string base 64 data url
                                var croppedImageDataURL = canvas.cropper('getCroppedCanvas' ).toDataURL("image/png"); 

                                $('#showDataShortcode').css({'background-image': first_link_all_final + ',' + 'url("'+ croppedImageDataURL +'")' }) ;
                                $('#showDataShortcode').css({'background-position': 'inherit' }) ;

                                        var height = $('.cropper-crop-box').height();
                                        var width = $('.cropper-crop-box').width();

                                        $('#showDataShortcode').css({'background-size': '100% 100%,'+width+'px '+height+'px'});
                                    },50);
        
                                });
                         
                               };
                               img.src = evt.target.result;
                            };
                            reader.readAsDataURL(file);
    
                        }
                        else {
                            console.log('non');
                        }
                          
                    };
                };
                request.send();


        })




    });





});