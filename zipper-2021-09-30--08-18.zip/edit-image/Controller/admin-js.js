$(document).ready(function() {
    $('.meuble-form').hide() ;
    $('.paint-form').hide() ;

    $('#btn-paint').on('click', function() {
        $('.paint-form').show() ;
        $('.meuble-form').hide() ;
    })  

    $('#btn-meuble').on('click', function() {
        $('.meuble-form').show() ;
        $('.paint-form').hide() ;
    })

    // check on end off
    $('.checkbox').on('click', function() {
        console.log( $(this).children('label')[0].textContent = "off") ;
    })

})