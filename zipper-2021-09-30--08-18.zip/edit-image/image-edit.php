<?php
/**
* Plugin Name: Image Editor Rah jean
* Plugin URI: 
* Description: Editeur d'image 
* Version: 1.0
* Author: Rah jean
* Author URI: http://yourwebsiteurl.com/
**/


function edit_image_menu() {
    $customMenu = add_menu_page('Edit', 'Edit Image', 'manage_options', 'edit_image_menu', 'edit_image_menu_main', 'dashicons-image-crop');
}
add_action('admin_menu', 'edit_image_menu') ;

function edit_image_menu_main() {
    require('Controller/edit_image_menu_main.php') ;
}

function pw_load_scripts() {

    wp_register_style('css-admin', plugins_url('/edit-image/Publics/css/admin-css.css', dirname(__FILE__) ));
    wp_enqueue_style('css-admin');

    wp_register_style('bootstrap', plugins_url('/Publics/css/bootstrap.min.css',__FILE__ ));
    wp_enqueue_style('bootstrap');

    wp_enqueue_script( 'admin-jquery', plugins_url('/Publics/lib/jquery.js',__FILE__ ) );
    wp_enqueue_script("jquery");
    
    wp_enqueue_script( 'admin-js', plugins_url('/Controller/admin-js.js',__FILE__ ), array( 'jquery' ), '1.0.0', true ); 
    wp_enqueue_script( 'popper', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js' );
    wp_enqueue_script( 'bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js' );
    

}
add_action('admin_enqueue_scripts', 'pw_load_scripts');

function custom_js() {

    wp_register_style('custom_css', plugins_url('/Publics/css/style.css',__FILE__ ));
    wp_enqueue_style('custom_css');

    wp_register_style('bootstrap', plugins_url('/Publics/css/bootstrap.min.css',__FILE__ ));
    wp_enqueue_style('bootstrap');

    wp_register_style('cropper-css', 'https://cdnjs.cloudflare.com/ajax/libs/cropper/2.3.3/cropper.css');
    wp_enqueue_style('cropper-css');

    wp_enqueue_script( 'jquery_custom', plugins_url( '/Publics/lib/jquery.js', __FILE__) );
   
    wp_enqueue_script( 'my_custom_shortcode', plugins_url( '/Controller/main-shortcode.js', __FILE__ ) );
    
    wp_enqueue_script( 'popper', 'https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js' );

    wp_enqueue_script( 'bootstrap-js', 'https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js' );

    wp_enqueue_script( 'cropper-js', 'https://cdnjs.cloudflare.com/ajax/libs/cropper/2.3.3/cropper.js' );

    wp_enqueue_script( 'my_custom_js', plugins_url( '/Controller/main.js', __FILE__ ) );

}
add_action('wp_enqueue_scripts','custom_js');


function shortcode_bienvenue(){
    return "<div id='custom_edit_shortcode'></div>";
}
add_shortcode('shortcode_bienvenue', 'shortcode_bienvenue');