<?php


$path = $_SERVER['DOCUMENT_ROOT'];

include_once $path . '/wp-config.php'; //*************** */
include_once $path . '/wp-load.php';//*************** */
include_once $path . '/wp-includes/wp-db.php';//*************** */
include_once $path . '/wp-includes/pluggable.php';//*************** */

$select_meubles = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles " );
$select_paints  = $wpdb->get_results( " SELECT * FROM wp_edit_image_paints " );

$select_bureau  = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'bureau' " );
$select_chambre = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'chambre' " );
$select_cuisine = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'cuisine' " );
$select_enfant  = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'enfant' " );
$select_entree  = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'entree' " );
$select_sdb     = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'sdb' " );
$select_salon   = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'salon' " );

?>

<div class="container-fluid">

    <div class="row">

          <div class="col-md-8" >
             <div id="showData"></div>
          </div>

          <div class="col-md-4 content content-box" style="background-color: #4b4b4b; height: 350px;padding: 10px;" >

               <div class="container-fluid"  >
                    <h5 style="color: #ffff;" >Choisissez un Meuble</h5>
                    <div class="row" ><span id="back">< Retour</span> </div>
                    <div class="row" id="marge" >

                         <div class="col-md-6" >
                              <div class="row colapse-div bureau" data-toggle="collapse" data-target="#demo1" >
                                   <h6>Bureau</h6>
                              </div>
                         </div>
                         <div class="col-md-6" >
                              <div class="row colapse-div chambre" data-toggle="collapse" data-target="#demo2" >
                                   <h6>Chambre</h6>
                              </div>
                         </div>

                         <div class="col-md-6" >
                              <div class="row colapse-div cuisine" data-toggle="collapse" data-target="#demo3" >
                                   <h6>Cuisine</h6>
                              </div>
                         </div>

                         <div class="col-md-6" >
                              <div class="row colapse-div enfant" data-toggle="collapse" data-target="#demo4" >
                                   <h6>Enfant</h6>
                              </div>
                         </div>

                         <div class="col-md-6" >
                              <div class="row colapse-div entree" data-toggle="collapse" data-target="#demo5" >
                                   <h6>Entrée</h6>
                              </div>
                         </div>

                         <div class="col-md-6" >
                              <div class="row colapse-div sdb" data-toggle="collapse" data-target="#demo6" >
                                   <h6>Salle de bain</h6>
                              </div>
                         </div>

                         <div class="col-md-6" >
                              <div class="row colapse-div salon" data-toggle="collapse" data-target="#demo7" >
                                   <h6>Salon</h6>
                              </div>
                         </div>


                         <!-- Data collapse debut -->
                         <div id="demo1" class="collapse">
                              <?php
                                        foreach ($select_bureau as $k ) {

                                        echo '     
                                                  <div class="data" >
                                                            <img class="img-paint" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" >';
                                                            if($k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                                                 echo '<img class="img-paint pixel_bg" src="'. $k->url_noir_blanc .'" alt="" >' ;
                                                            }
                                                            
                                             echo' 
                                                  </div>

                                                  ' ;
                                        }
                                   ?>
                                   
                         </div>

                         <div id="demo2" class="collapse">
                              <?php
                                        foreach ($select_chambre as $k ) {

                                        echo '     
                                                  <div class="data" >
                                                            <img class="img-paint" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" >';
                                                            if($k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                                                 echo '<img class="img-paint pixel_bg" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                                            }
                                                            
                                             echo' 
                                                  </div>

                                                  ' ;
                                        }
                                   ?>
                                   
                         </div>

                         <div id="demo3" class="collapse">
                              <?php
                                        foreach ($select_cuisine as $k ) {

                                        echo '     
                                                  <div class="data" >
                                                            <img class="img-paint" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" >';
                                                            if($k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                                                 echo '<img class="img-paint pixel_bg" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                                            }
                                                            
                                             echo' 
                                                  </div>

                                                  ' ;
                                        }
                                   ?>
                                   
                         </div>


                         <div id="demo4" class="collapse">
                              <?php
                                        foreach ($select_enfant as $k ) {

                                        echo '     
                                                  <div class="data" >
                                                            <img class="img-paint" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" >';
                                                            if($k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                                                 echo '<img class="img-paint pixel_bg" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                                            }
                                                            
                                             echo' 
                                                  </div>

                                                  ' ;
                                        }
                                   ?>
                                   
                         </div>

                         <div id="demo5" class="collapse">
                              <?php
                                        foreach ($select_entree as $k ) {

                                        echo '     
                                                  <div class="data" >
                                                            <img class="img-paint" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" >';
                                                            if($k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                                                 echo '<img class="img-paint pixel_bg" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                                            }
                                                            
                                             echo' 
                                                  </div>

                                                  ' ;
                                        }
                                   ?>
                                   
                         </div>

                         <div id="demo6" class="collapse">
                              <?php
                                        foreach ($select_sdb as $k ) {

                                        echo '     
                                                  <div class="data" >
                                                            <img class="img-paint" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" >';
                                                            if($k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                                                 echo '<img class="img-paint pixel_bg" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                                            }
                                                            
                                             echo' 
                                                  </div>

                                                  ' ;
                                        }
                                   ?>
                                   
                         </div>

                         <div id="demo7" class="collapse">
                              <?php
                                        foreach ($select_salon as $k ) {

                                        echo '     
                                                  <div class="data" >
                                                            <img class="img-paint" src="'. $k->url_couleur .'" alt="" id="'. $k->name .'" >';
                                                            if($k->url_noir_blanc != '/wp-content/plugins/edit-image/Publics/Images/meubles/' ) {
                                                                 echo '<img class="img-paint pixel_bg" src="'. $k->url_noir_blanc .'" alt="" id="'. $k->name .'" >' ;
                                                            }
                                                            
                                             echo' 
                                                  </div>

                                                  ' ;
                                        }
                                   ?>
                                   
                         </div>


                    </div>

               </div>
          </div>

    </div>

    <div class="row save float-left" >
       <button id="foo">Télèchargez le model</button>
    </div>



</div>




<script src="/wp-content/plugins/edit-image/Publics/lib/dom-to-image-master/src/dom-to-image.js" ></script>
<script src="/wp-content/plugins/edit-image/Publics/lib/FileSaver.js-master/src/FileSaver.js" ></script>

<script>

var node = document.getElementById('showData');
var btn = document.getElementById('foo');

btn.onclick = function() {

  domtoimage.toBlob(document.getElementById('showData')).then(function(blob) {
     window.saveAs(blob, 'modele.png');
    });
}



$(document).ready(function() {

     $('#back').hide() ;

     $('.bureau').on('click', function() {
         $('#back').show() ;
         $('.colapse-div').hide();
     }) ;

     $('.chambre').on('click', function() {
         $('#back').show() ;
         $('.colapse-div').hide();
     }) ;

     $('.cuisine').on('click', function() {
         $('#back').show() ;
         $('.colapse-div').hide();
     }) ;

     $('.enfant').on('click', function() {
         $('#back').show() ;
         $('.colapse-div').hide();
     }) ;

     $('.entree').on('click', function() {
         $('#back').show() ;
         $('.colapse-div').hide();
     }) ;

     $('.sdb').on('click', function() {
         $('#back').show() ;
         $('.colapse-div').hide();
     }) ;
     
     $('.salon').on('click', function() {
         $('#back').show() ;
         $('.colapse-div').hide();
     }) ;

     $('#back').on('click', function() {
          $(".collapse").collapse('hide');
          $('.colapse-div').show();
          $('#back').hide() ;
          $('#marge').show();
     }) ;

    $('.showbtn').on('click', function() {
        $('.zindex').addClass('blindShow');
    }) ;
    $('.hidebtn').on('click', function() {
        $('.zindex').removeClass('blindShow');
    }) ;
     

})


</script>