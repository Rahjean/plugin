<?php 

$path = $_SERVER['DOCUMENT_ROOT'];

include_once $path . '/wp-config.php'; //*************** */
include_once $path . '/wp-load.php';//*************** */
include_once $path . '/wp-includes/wp-db.php';//*************** */
include_once $path . '/wp-includes/pluggable.php';//*************** */

// $selectProductWithGalleryAndPublish = $wpdb->get_results(" SELECT * FROM `wp_posts` WHERE `post_type` LIKE '%product%' AND `post_status` LIKE '%publish%' ") ;

// foreach ( $selectProductWithGalleryAndPublish as $value ) {
//     $productGalleryPlushih = $value->ID  ; 

//     $select_paints = $wpdb->get_results( " SELECT * FROM `wp_postmeta` WHERE ( `post_id` LIKE $productGalleryPlushih AND `meta_key` LIKE '%_wp_attached_file%') AND (`meta_value` LIKE '%jpeg%' OR `meta_value` LIKE '%.jpg%' ) " );
// }

// ALAINA IZAY PUBLIER REHETRA

// // ALAINA ILAY MANANA 'post_parent mitovy amlay id anaty postmeta'
// $postPrentWithId = $wpdb->get_results(("SELECT * FROM `wp_posts` WHERE `post_parent` LIKE '%=====%' ");

// // ALAINA IZAY MANANA POST_ID = POST_PARENT
// (" SELECT * FROM `wp_postmeta` WHERE `meta_key` LIKE '_wp_attached_file' ") ;


// $select_paints = $wpdb->get_results( " SELECT * FROM `wp_postmeta` WHERE (`meta_key` LIKE '%_wp_attached_file%') AND (`meta_value` LIKE '%jpeg%' OR `meta_value` LIKE '%.jpg%' ) " );
// $select_meubles = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles " );
$select_bureau  = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'bureau' " );
$select_chambre = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'chambre' " );
$select_cuisine = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'cuisine' " );
$select_enfant  = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'enfant' " );
$select_entree  = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'entree' " );
$select_sdb     = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'sdb' " );
$select_salon   = $wpdb->get_results( " SELECT * FROM wp_edit_image_meubles Where category = 'salon' " );

global $woocommerce;

$product = wc_get_product( $post->ID );

echo $product ;

?>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link href="https://netdna.bootstrapcdn.com/font-awesome/3.2.1/css/font-awesome.css" rel="stylesheet">
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<div class="container-fluid">
    <div class="row main mt-5">
        <div class="col-xl-4 col-md-12 col-sm-12">
            <div class="accordion accordion-flush py-2" id="accordionParent">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingOne">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
                        Choix de la pièce
                    </button>
                    </h2>
                    <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionParent">
                        <div class="accordion-body p-1">
                            <div class="accordion accordion-flush" id="accordionPiece">

                                <!-- ******** Bureau ******** -->
                                <div class="accordion-item border card mb-2 rounded-3">
                                    <h2 class="accordion-header" id="flush-headingOnePiece-meuble">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOnePieceMeuble" aria-expanded="false" aria-controls="flush-collapseOnePieceMeuble">
                                            Bureau
                                        </button>
                                    </h2>
                                    <div id="flush-collapseOnePieceMeuble" class="accordion-collapse collapse" aria-labelledby="flush-headingOnePiece-meuble" data-bs-parent="#accordionPiece">
                                        <div class="accordion-body p-1">
                                            <div class="carousel slide multi-item-carousel" id="theCarouselMeuble">
                                                <div class="carousel-inner row w-100 mx-auto">
                                                        <?php
                                                            foreach ($select_bureau as $value) {
                                                                echo('<div class="carousel-item col-md-4">
                                                                <img src="'.$value->url_couleur.'" class="z-index img-fluid mx-auto d-block">
                                                                <img class="pixel_bg_shortcode" src="'.$value->url_noir_blanc.'" alt="">
                                                                </div>') ;
                                                            }
                                                        ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#theCarouselMeuble" role="button" data-slide="prev">
                                                    <i class="icon-angle-left"></i>
                                                </a>
                                                <a class="carousel-control-next" href="#theCarouselMeuble" role="button" data-slide="next">
                                                    <i class="icon-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- ******** Chambre ******** -->
                                <div class="accordion-item border card mb-2 rounded-3">
                                    <h2 class="accordion-header" id="flush-headingOnePiece-chambre">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOnePieceChambre" aria-expanded="false" aria-controls="flush-collapseOnePieceChambre">
                                            Chambre
                                        </button>
                                    </h2>
                                    <div id="flush-collapseOnePieceChambre" class="accordion-collapse collapse" aria-labelledby="flush-headingOnePiece-chambre" data-bs-parent="#accordionPiece">
                                        <div class="accordion-body p-1">
                                            <div class="carousel slide multi-item-carousel" id="theCarouselChambre">
                                                <div class="carousel-inner row w-100 mx-auto">
                                                        <?php
                                                            foreach ($select_chambre as $value) {
                                                                echo('<div class="carousel-item col-md-4">
                                                                <img src="'.$value->url_couleur.'" class="z-index img-fluid mx-auto d-block">
                                                                <img class="pixel_bg_shortcode" src="'.$value->url_noir_blanc.'" alt="">
                                                                </div>') ;
                                                            }
                                                        ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#theCarouselChambre" role="button" data-slide="prev">
                                                    <i class="icon-angle-left"></i>
                                                </a>
                                                <a class="carousel-control-next" href="#theCarouselChambre" role="button" data-slide="next">
                                                    <i class="icon-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- ******** Cuisine ******** -->
                                <div class="accordion-item border card mb-2 rounded-3">
                                    <h2 class="accordion-header" id="flush-headingOnePiece-cuisine">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOnePieceCuisine" aria-expanded="false" aria-controls="flush-collapseOnePieceCuisine">
                                            Cuisine
                                        </button>
                                    </h2>
                                    <div id="flush-collapseOnePieceCuisine" class="accordion-collapse collapse" aria-labelledby="flush-headingOnePiece-cuisine" data-bs-parent="#accordionPiece">
                                        <div class="accordion-body p-1">
                                            <div class="carousel slide multi-item-carousel" id="theCarouselCuisine">
                                                <div class="carousel-inner row w-100 mx-auto">
                                                        <?php
                                                            foreach ($select_cuisine as $value) {
                                                                echo('<div class="carousel-item col-md-4">
                                                                <img src="'.$value->url_couleur.'" class="z-index img-fluid mx-auto d-block">
                                                                <img class="pixel_bg_shortcode" src="'.$value->url_noir_blanc.'" alt="">
                                                                </div>') ;
                                                            }
                                                        ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#theCarouselCuisine" role="button" data-slide="prev">
                                                    <i class="icon-angle-left"></i>
                                                </a>
                                                <a class="carousel-control-next" href="#theCarouselCuisine" role="button" data-slide="next">
                                                    <i class="icon-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- ******** Enfant ******** -->
                                <div class="accordion-item border card mb-2 rounded-3">
                                    <h2 class="accordion-header" id="flush-headingOnePiece-enfant">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOnePieceEnfant" aria-expanded="false" aria-controls="flush-collapseOnePieceEnfant">
                                            Enfant
                                        </button>
                                    </h2>
                                    <div id="flush-collapseOnePieceEnfant" class="accordion-collapse collapse" aria-labelledby="flush-headingOnePiece-enfant" data-bs-parent="#accordionPiece">
                                        <div class="accordion-body p-1">
                                            <div class="carousel slide multi-item-carousel" id="theCarouselEnfant">
                                                <div class="carousel-inner row w-100 mx-auto">
                                                        <?php
                                                            foreach ($select_enfant as $value) {
                                                                echo('<div class="carousel-item col-md-4">
                                                                <img src="'.$value->url_couleur.'" class="z-index img-fluid mx-auto d-block">
                                                                <img class="pixel_bg_shortcode" src="'.$value->url_noir_blanc.'" alt="">
                                                                </div>') ;
                                                            }
                                                        ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#theCarouselEnfant" role="button" data-slide="prev">
                                                    <i class="icon-angle-left"></i>
                                                </a>
                                                <a class="carousel-control-next" href="#theCarouselEnfant" role="button" data-slide="next">
                                                    <i class="icon-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- ******** Entrée ******** -->
                                <div class="accordion-item border card mb-2 rounded-3">
                                    <h2 class="accordion-header" id="flush-headingOnePiece-entree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOnePieceEntree" aria-expanded="false" aria-controls="flush-collapseOnePieceEntree">
                                            Entrée
                                        </button>
                                    </h2>
                                    <div id="flush-collapseOnePieceEntree" class="accordion-collapse collapse" aria-labelledby="flush-headingOnePiece-entree" data-bs-parent="#accordionPiece">
                                        <div class="accordion-body p-1">
                                            <div class="carousel slide multi-item-carousel" id="theCarouselEntree">
                                                <div class="carousel-inner row w-100 mx-auto">
                                                        <?php
                                                            foreach ($select_entree as $value) {
                                                                echo('<div class="carousel-item col-md-4">
                                                                <img src="'.$value->url_couleur.'" class="z-index img-fluid mx-auto d-block">
                                                                <img class="pixel_bg_shortcode" src="'.$value->url_noir_blanc.'" alt="">
                                                                </div>') ;
                                                            }
                                                        ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#theCarouselEntree" role="button" data-slide="prev">
                                                    <i class="icon-angle-left"></i>
                                                </a>
                                                <a class="carousel-control-next" href="#theCarouselEntree" role="button" data-slide="next">
                                                    <i class="icon-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- ******** Salle de bain ******** -->
                                <div class="accordion-item border card mb-2 rounded-3">
                                    <h2 class="accordion-header" id="flush-headingOnePiece-salle-de-bain">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOnePieceSalleBain" aria-expanded="false" aria-controls="flush-collapseOnePieceSalleBain">
                                            Salle de bain
                                        </button>
                                    </h2>
                                    <div id="flush-collapseOnePieceSalleBain" class="accordion-collapse collapse" aria-labelledby="flush-headingOnePiece-salle-de-bain" data-bs-parent="#accordionPiece">
                                        <div class="accordion-body p-1">
                                            <div class="carousel slide multi-item-carousel" id="theCarouselsdb">
                                                <div class="carousel-inner row w-100 mx-auto">
                                                        <?php
                                                            foreach ($select_sdb as $value) {
                                                                echo('<div class="carousel-item col-md-4">
                                                                <img src="'.$value->url_couleur.'" class="z-index img-fluid mx-auto d-block">
                                                                <img class="pixel_bg_shortcode" src="'.$value->url_noir_blanc.'" alt="">
                                                                </div>') ;
                                                            }
                                                        ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#theCarouselsdb" role="button" data-slide="prev">
                                                    <i class="icon-angle-left"></i>
                                                </a>
                                                <a class="carousel-control-next" href="#theCarouselsdb" role="button" data-slide="next">
                                                    <i class="icon-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- ******** Salon ******** -->
                                <div class="accordion-item border card mb-2 rounded-3">
                                    <h2 class="accordion-header" id="flush-headingOnePiece-salon">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOnePieceSalon" aria-expanded="false" aria-controls="flush-collapseOnePieceSalon">
                                            Salon
                                        </button>
                                    </h2>
                                    <div id="flush-collapseOnePieceSalon" class="accordion-collapse collapse" aria-labelledby="flush-headingOnePiece-salon" data-bs-parent="#accordionPiece">
                                        <div class="accordion-body p-1">
                                            <div class="carousel slide multi-item-carousel" id="theCarouselSalon">
                                                <div class="carousel-inner row w-100 mx-auto">
                                                        <?php
                                                            foreach ($select_salon as $value) {
                                                                echo('<div class="carousel-item col-md-4">
                                                                <img src="'.$value->url_couleur.'" class="z-index img-fluid mx-auto d-block">
                                                                <img class="pixel_bg_shortcode" src="'.$value->url_noir_blanc.'" alt="">
                                                                </div>') ;
                                                            }
                                                        ?>
                                                </div>
                                                <a class="carousel-control-prev" href="#theCarouselSalon" role="button" data-slide="prev">
                                                    <i class="icon-angle-left"></i>
                                                </a>
                                                <a class="carousel-control-next" href="#theCarouselSalon" role="button" data-slide="next">
                                                    <i class="icon-angle-right"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="flush-headingTwo">
                    <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
                        Choix du papier peint
                    </button>
                    </h2>
                    <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionParent">
                        <div class="accordion-body p-1">
                            <div class="accordion accordion-flush" id="accordionPeint">

                        <?php


                        $orderby = 'name';
                        $order = 'asc';
                        $hide_empty = false ;
                        $cat_args = array(
                            'orderby'    => $orderby,
                            'order'      => $order,
                            'hide_empty' => $hide_empty,
                        );

                        // Custom query.
                        $query = new WP_Query( $cat_args );

                        // Check that we have query results.
                        if ( $query->have_posts() ) {

                            // Start looping over the query results.
                            while ( $query->have_posts() ) { $query->the_post();

                                $product_categories = get_terms( 'product_cat', $cat_args );

                                if( !empty($product_categories) ){

                                    foreach ($product_categories as $key => $category) {

                                        echo '
                                        <div class="accordion-item border card mb-2 rounded-3">

                                        <h2 class="accordion-header" id="flush-'.$category->term_id.'-un">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-'.$category->term_id.'" aria-expanded="false" aria-controls="flush-'.$category->term_id.'">
                                                '.$category->name.'
                                            </button>
                                        </h2>

                                        <div id="flush-'.$category->term_id.'" class="accordion-collapse collapse" aria-labelledby="flush-'.$category->term_id.'-un" data-bs-parent="#accordionPeint">
                                            <div class="accordion-body p-1">
                                                <div class="carousel slide multi-item-carousel" id="theCarouselAllPeint'.$category->term_id.'">
                                                    <div class="carousel-inner row w-100 mx-auto">' ;

                                                    $args = array(
                                                        'post_type'      => 'product',
                                                        'posts_per_page' => 10,
                                                        'product_cat'    => $category->name
                                                    );
                                    
                                                    $loop = new WP_Query( $args );
                                    
                                                    while ( $loop->have_posts() ) : $loop->the_post();
                                    
                                                        global $product;
                                                    
                                                        $attachment_ids = $product->get_id();
                                
                                                        $product_url = new WC_product($attachment_ids);
                                
                                                        $attachment_ids_final = $product_url->get_gallery_image_ids();
                                                    
                                                        foreach( $attachment_ids_final as $attachment_id ){
                                
                                                                $Original_image_url = wp_get_attachment_url( $attachment_id );
                                
                                                                echo('<div class="carousel-item col-md-4">');

                                                                if ($Original_image_url) {
                                                                    echo('<img src="'.$Original_image_url.'" class="img-paint-shortcode img-fluid mx-auto d-block">') ;
                                                                } else {
                                                                   echo('Aucun produit disponnible') ;
                                                                }
                                                                
                                                                 echo('</div>') ;
                                                        } 
                                    
                                                    endwhile;
                                                    wp_reset_query();

                                            echo '</div>
                                                    <a class="carousel-control-prev" href="#theCarouselAllPeint'.$category->term_id.'" role="button" data-slide="prev">
                                                        <i class="icon-angle-left"></i>
                                                    </a>
                                                    <a class="carousel-control-next" href="#theCarouselAllPeint'.$category->term_id.'" role="button" data-slide="next">
                                                        <i class="icon-angle-right"></i>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>

                                    </div>
                                    ';

                                    }
                                }                                           
                            }
                        }    

                        ?>



                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-xl-8 col-md-12 col-sm-12 other p-0">
            <div id="showDataShortcode" class="img">
                <!-- <img src="./pink-and-peach-abstract-paint-brush-strokes-wallpaper-mural-Plain-820x532-1.jpg" class="img-fluid rounded-3" alt=""> -->
            </div>

            <div class="information row">
                <div class="col-xl-7 border-right d-flex justify-content-between">
                    <button id="drag" type="button" class="btn btn-sm btn-danger rounded-pill">
                        <span class="btn-label">
                            <i class="icon-move mx-1"></i>
                        </span>
                        <b>Déplacer</b>
                    </button>

                    <button id="btnCrop"  type="button" data-toggle="modal" data-target="#pers_peint" class="btn btn-sm btn-danger rounded-pill">
                        <span class="btn-label">
                            <i class="icon-crop mx-1"></i>
                        </span>
                        <b>Recadrer</b>
                    </button>

                    <!--<button type="button" class="btn btn-sm rounded-pill">
                        <span class="btn-label">
                            <i class="icon-check-empty mx-1"></i>
                            </span>
                        Inverser l'image
                    </button> -->
                </div>

                <div class="col-xl-5 d-flex justify-content-between">
                    <button type="button" class="btn btn-sm btn-danger rounded-pill">
                        <span class="btn-label">
                            <i class="fa fa-plus mx-1"></i>
                        </span>
                        Acheter le papier peint
                    </button>

                    <div class="d-flex align-items-center">
                        <i class="icon-share-alt mx-2"></i>
                        <i id="foo" class="icon-save mx-2"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="pers_peint" role="dialog">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-md">

        <!-- Modal content-->
        <div class="modal-content">
            <div class="modal-body">
                <div class="b-init" id="builder_popup">
                    <div id="canvas_empty" >
                        <canvas id="canvas">
                            Your browser does not support the HTML5 canvas element.
                        </canvas>
                    </div>		
                </div>
            </div>

            <div class="modal-footer">
                <button id="saveCropper" type="button" class="btn btn-success" data-dismiss="modal">Rogner</button>
                <button id="closeCropper" type="button" class="btn btn-danger" data-dismiss="modal">Annuler</button>

            </div>
        </div>
        
    </div>
</div>


<script src="/wp-content/plugins/edit-image/Publics/lib/dom-to-image-master/src/dom-to-image.js" ></script>
<script src="/wp-content/plugins/edit-image/Publics/lib/FileSaver.js-master/src/FileSaver.js" ></script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>



<script>

    var node = document.getElementById('showDataShortcode');
    var btn = document.getElementById('foo');

    btn.onclick = function() {

    domtoimage.toBlob(document.getElementById('showDataShortcode')).then(function(blob) {
        window.saveAs(blob, 'modele.png');
        });
    }

    $('.carousel').carousel({
        interval: false,
    });

    setTimeout(() => {
        $('#theCarouselMeuble .carousel-inner .carousel-item').first().addClass('active');
        $('#theCarouselChambre .carousel-inner .carousel-item').first().addClass('active');
        $('#theCarouselCuisine .carousel-inner .carousel-item').first().addClass('active');
        $('#theCarouselEnfant .carousel-inner .carousel-item').first().addClass('active');
        $('#theCarouselEntree .carousel-inner .carousel-item').first().addClass('active');
        $('#theCarouselsdb .carousel-inner .carousel-item').first().addClass('active');
        $('#theCarouselSalon .carousel-inner .carousel-item').first().addClass('active');
        $('#theCarouselAllPeint .carousel-inner .carousel-item').first().addClass('active');
    }, 500);


    $('.accordion-button').on('click', function() {
        $(this).parent().parent().find('.accordion-collapse .carousel-item').first().addClass('active');
    }) ;

</script>